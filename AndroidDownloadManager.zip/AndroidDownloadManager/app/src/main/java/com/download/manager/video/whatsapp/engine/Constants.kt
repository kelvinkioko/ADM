package com.download.manager.video.whatsapp.engine

class Constants{
    val FOLDER_NAME = "/WhatsApp/Media/.Statuses"
    val DOWNLOADER_FOLDER = "/Android Download Manager/Whatsapp ADM"
    val INSTAGRAM_FOLDER = "/Android Download Manager/Instagram ADM"
    val PARENT_FOLDER = "/Android Download Manager"
}