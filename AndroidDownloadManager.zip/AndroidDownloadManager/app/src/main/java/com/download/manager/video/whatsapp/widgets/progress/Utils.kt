package com.download.manager.video.whatsapp.widgets.progress

import android.content.res.Resources

fun dpToPx(dp: Int) = (dp * Resources.getSystem().displayMetrics.density).toInt()