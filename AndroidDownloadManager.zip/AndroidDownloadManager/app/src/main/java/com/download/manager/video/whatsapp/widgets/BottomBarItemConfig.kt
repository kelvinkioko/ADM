package com.download.manager.video.whatsapp.widgets

import android.graphics.drawable.Drawable

data class BottomBarItemConfig(
    val text: String,
    val drawable: Drawable,
    val index: Int
)